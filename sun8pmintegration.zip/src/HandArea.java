

import java.awt.*;
import javax.swing.*;

public class HandArea extends JPanel{

    public HandArea(){
        this.setLayout( new GridBagLayout());
    }


}
